function y=H1(w)
% Funci�n de transferencia que solamente aten�a una se�al sin retardar
% PAR�METROS:
%     w valores de frecuencia.

y=0.7*ones(size(w));