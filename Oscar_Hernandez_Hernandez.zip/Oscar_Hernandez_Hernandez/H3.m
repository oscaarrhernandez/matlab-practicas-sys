function y=H3(w)
% Funci�n de transferencia que produce retardo en una se�al sin atenuarla
% PAR�METROS:
%     w valores de frecuencia.

y=exp(-j*0.1*w);