[w,coef,t,y]=rectangular_c(5,0.002,0.01,-0.1,0.1,50,0);
plot(t,y);