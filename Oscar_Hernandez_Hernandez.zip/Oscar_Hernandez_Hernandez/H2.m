function y=H2(w)
% Funci�n de transferencia que produce distorsi�n de una se�al sin retardar
% PAR�METROS:
%     w valores de frecuencia.

y=sin(w/20);